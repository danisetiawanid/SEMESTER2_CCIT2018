/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Koneksi.Koneksi;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author M.Dani Setiawan
 */
public class CoffeeModel {
   String id_booking,nama_tim,no_lapangan,hari,jam, ida;
   String id_akun,nama,email,password_akun;
   String id_admin,username,passoword_admin;
   String ID_Coffee,Coffee_Name,Stock,Price,Expired;
   Koneksi db = null;
  
    public CoffeeModel() {
        db = new Koneksi();
    }

    public void setId_admin(String id_admin) {
        this.id_admin = id_admin;
    }

    public String getId_admin() {
        return id_admin;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getUsername() {
        return username;
    }

    public void setPassoword_admin(String passoword_admin) {
        this.passoword_admin = passoword_admin;
    }

    public String getPassoword_admin() {
        return passoword_admin;
    }

    public void setId_akun(String id_akun) {
        this.id_akun = id_akun;
    }

    public String getId_akun() {
        return id_akun;
    }

    

 
     public String getNama() {
        return nama;
    }
 
    public void setNama(String nama) {
        this.nama = nama;
    }
    
    public String getEmail() {
        return email;
    }
 
    public void setEmail(String email) {
        this.email = email;
    }
    
       public String getPassword() {
        return password_akun;
    }
 
    public void setPassword(String password) {
        this.password_akun = password;
    }

   
    public void simpanbelicoffe(){
        String sql="INSERT INTO booking values('"+id_akun+"','"+nama_tim+"','"+no_lapangan+"','"+hari+"','"+jam+"')";
        String sql2="INSERT INTO booking values('"+id_akun+"','"+nama_tim+"','"+no_lapangan+"','"+hari+"','"+jam+"')";
        db.simpanData(sql);
    }

    public void simpan_akun(){
        String sql="INSERT INTO db_coffee_akun values('"+nama+"','"+email+"','"+password_akun+"')";
        db.simpanData(sql);
    }
    
    public void update_akun(){
        String sql="UPDATE akun SET nama='"+nama+"',email='"+email+"',password='"+password_akun+"' WHERE id_akun='"+id_akun+"'";
        db.simpanData(sql);
        System.out.println(sql);
    }
    public void hapus_akun(){
        String sql="DELETE FROM akun WHERE id_akun='"+id_akun+"'";
        db.simpanData(sql);
        System.out.println("");
    }
    
    
    
    public void setCoffee_Name(String Coffee_Name) {
        this.Coffee_Name = Coffee_Name;
    }

    public String getCoffee_Name() {
        return Coffee_Name;
    }

    public void setStock(String Stock) {
        this.Stock = Stock;
    }

    public String getStock() {
        return Stock;
    }


    public void setID_Coffee(String ID_Coffee) {
        this.ID_Coffee = ID_Coffee;
    }

    public String getID_Coffee() {
        return ID_Coffee;
    }

    public void setPrice(String Price) {
        this.Price = Price;
    }

    public String getPrice() {
        return Price;
    }

    public void setExpired(String Expired) {
        this.Expired = Expired;
    }

    public String getExpired() {
        return Expired;
    }
    
    public List CoffeeDetail() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;

        try {
            String sql = "select * from db_coffee_detail";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel um = new CoffeeModel();
                um.setID_Coffee(rs.getString("ID_Coffee"));
                um.setCoffee_Name(rs.getString("Coffee_Name"));
                um.setStock(rs.getString("Stock"));
                um.setPrice(rs.getString("Price"));
                um.setExpired(rs.getString("Expired"));
                data.add(um);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalahan Saat menampilkan data Field" + ex);
        }
        return data;
    }
    
    
    public List CoffeeAkun() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;

        try {
            String sql = "select * from db_coffee_akun";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel um = new CoffeeModel();
               um.setId_akun(rs.getString("id_akun"));
               um.setNama(rs.getString("nama"));
               um.setEmail(rs.getString("email"));
               um.setPassword(rs.getString("password_akun"));
               
                data.add(um);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalahan Saat menampilkan data Field" + ex);
        }
        return data;
    }
    
    public List cariIdAkun() {
        List<CoffeeModel> data = new ArrayList<CoffeeModel>();
        ResultSet rs = null;
        try {
            String sql = "SELECT * FROM db_coffee_akun WHERE id_akun='"+id_akun+"'";
            rs = db.ambilData(sql);
            while (rs.next()) {
                CoffeeModel m = new CoffeeModel();
                m.setId_akun(rs.getString("id_akun"));
                m.setNama(rs.getString("nama"));
                m.setEmail(rs.getString("email"));
                m.setPassword(rs.getString("password_akun"));
                data.add(m);

            }
            db.diskonek(rs);
        } catch (Exception ex) {
            System.out.println("Terjadi Kesalah Saat menampilkan Cari IdAkun" + ex);
        }
        return data;
    }
    
    public List LoginUser(String email, String password_akun) {
        List data = new ArrayList();
        ResultSet rs = null;
        try {
            String sql = "select * from db_coffee_akun where email='" + email + "' and password_akun='" + password_akun + "'";
            rs = db.ambilData(sql);
            
            while (rs.next()) {
                CoffeeModel am = new CoffeeModel();
                am.setId_akun(rs.getString("id_akun"));
                am.setNama(rs.getString("nama"));      
                am.setEmail(rs.getString("email"));                
                am.setPassword(rs.getString("password_akun"));
                data.add(am);
            }
            db.diskonek(rs);
        } catch (Exception a) {
            System.out.println("Terjadi kesalahaan cari login user, pada :\n" + a);
        }
        return data;
    }
    
    public List LoginAdmin(String username, String password_admin) {
        List data = new ArrayList();
        ResultSet rs = null;
        try {
            String sql = "select * from db_coffee_admin where username='" + username + "' and password_admin='" + password_admin + "'";
            rs = db.ambilData(sql);
            
            while (rs.next()) {
                CoffeeModel am = new CoffeeModel();
                am.setId_admin(rs.getString("id_admin"));
                am.setUsername(rs.getString("username"));                   
                am.setPassoword_admin(rs.getString("password_admin"));
                data.add(am);
            }
            db.diskonek(rs);
        } catch (Exception a) {
            System.out.println("Terjadi kesalahaan cari login admin, pada :\n" + a);
        }
        return data;
    }
}
